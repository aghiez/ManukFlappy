﻿{
	"version": 1709169654,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/frame-sheet0.png",
		"images/backgrsheet-sheet0.png",
		"images/atassheet-sheet0.png",
		"images/bwhsheet-sheet0.png",
		"images/sprite-sheet0.png",
		"images/home-sheet0.png",
		"images/retry2-sheet0.png",
		"images/1mulai-sheet0.png",
		"images/3keluar-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}